# Fair AI Dashboard with Explainability & Energy Tracking

## Features
- Fair model (demographic parity) and unconstrained baseline
- SHAP explanations for every prediction
- Inference time / CPU / memory / CO2 tracking
- Fairness metrics (demographic parity difference)

## Run locally
```bash
pip install -r requirements.txt
streamlit run fair_ai_dashboard.py
```

## Deploy on Streamlit Cloud
1. Push this folder to GitHub
2. Connect the repo in Streamlit Cloud
3. Set the main file to `fair_ai_dashboard.py`
